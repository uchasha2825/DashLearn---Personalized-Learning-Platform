const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 3000;
const rooms = {}; // { roomName: [user1, user2, ...] }

app.use(express.static("public")); // Serve index.html, main.js, styles.css

io.on("connection", (socket) => {
  socket.on("join", (room, username) => {
    socket.join(room);
    socket.username = username;
    socket.room = room;

    if (!rooms[room]) rooms[room] = [];
    if (!rooms[room].includes(username)) {
      rooms[room].push(username);
    }

    io.to(room).emit("update-user-list", rooms[room]);
    socket.to(room).emit("user-joined", username);
  });

  socket.on("message", (data) => {
    io.to(data.room).emit("message", data);
  });

  socket.on("typing", (room) => {
    socket.to(room).emit("typing", room);
  });

  socket.on("start-call", (room) => {
    socket.to(room).emit("start-call", room);
  });

  socket.on("offer", ({ room, offer }) => {
    socket.to(room).emit("offer", { room, offer });
  });

  socket.on("answer", ({ room, answer }) => {
    socket.to(room).emit("answer", { room, answer });
  });

  socket.on("ice-candidate", ({ room, candidate }) => {
    socket.to(room).emit("ice-candidate", { room, candidate });
  });

  socket.on("disconnect", () => {
    const { room, username } = socket;
    if (room && rooms[room]) {
      rooms[room] = rooms[room].filter((user) => user !== username);
      io.to(room).emit("update-user-list", rooms[room]);
      socket.to(room).emit("user-left", username);
    }
  });
});

server.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
